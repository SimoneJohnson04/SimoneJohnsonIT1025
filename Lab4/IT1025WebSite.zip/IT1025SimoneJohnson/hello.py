#Program by Simone Johnson; code from Automate the Boring Stuff with Python

print('Hello world!')
print('What is your name?')
myName= input()
print('It is good to mett you, ' + myName)
print('The length of your name is: ')
print(len(myName))
print('What is your age?')
myAge = input()
print('You will be ' +str(int(myAge)+1) + ' in a year.')


      
